# Upload til server

Sådan:

* Stå i "roden" af mapperne, dér hvor index.html bør være.
* Marker alle filer, fx COMMAND + A.
* Højreklik på det markerede.
* Vælg "komprimer".

Resultatet er en zip-fil.

Fra kontrolpanelet på Simply.dk eller andet webhotel uploades og upakkes zippen i mappen. 

Husk, at markere, at serveren skal prøve at udpakke zippen efter upload ;-)

## FAQ: Billeder vises ikke ...

* Tjek, at stien til billedet er korrekt stavet med små og store bogstaver.
* Der må ikke være mellemrum i filnavne.
* Husk "../" foran filnavnet, hvis dit CSS ligger i en undermappe. 

